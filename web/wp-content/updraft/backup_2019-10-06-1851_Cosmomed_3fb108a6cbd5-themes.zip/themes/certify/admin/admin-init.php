<?php
if(is_admin()){
	require CERTIFY_ST_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}

require CERTIFY_ST_TEMPLATE_DIR . '/admin/inc/plugin-include-control.php';
require CERTIFY_ST_TEMPLATE_DIR . '/admin/inc/include-companion.php';


