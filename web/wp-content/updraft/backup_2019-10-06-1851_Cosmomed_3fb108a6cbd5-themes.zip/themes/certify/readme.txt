=== Certify ===

Contributors: spicethemes
Requires at least: 4.7
Tested up to: 5.0.2
Stable tag: 1.2.4.3
Multi-purpose WordPress theme

== Description ==

Certify is a responsive, multi-purpose WordPress theme. It's flexible and suitable for agencies, agency, blog, business, corporate, finance, account, consulting or portfolios. Customization is easy and straight-forward, with options provided that allow you to setup your site to perfectly fit your desired online presence.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0 ==

1. Released

== Screenshot Images ==

* All images are licensed under [CC0]
https://www.pexels.com/photo/apple-devices-books-business-coffee-572056/