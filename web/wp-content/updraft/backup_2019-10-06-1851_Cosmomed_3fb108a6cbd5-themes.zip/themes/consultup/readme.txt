﻿=== Consultup ===
Contributors: themeansar
Tags: three-columns, left-sidebar, right-sidebar, custom-logo, featured-images, threaded-comments, blog, e-commerce, news
Requires at least: 4.0.5
Tested up to:5.1
Stable tag: 1.5.4
Requires PHP: 5.2.4

== Theme License & Copyright ==
consultup is distributed under the terms of the GNU GPL
consultup -Copyright 2018 consultup, themeansar.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

consultup is a powerful bootstrap Wordpress theme for any business. woocommerce and any other kind of website purpose. It comes with all features these kind of shop page, blog page, Contact form seven working, custom logo

===========
ABOUT THEME
=========== 
Theme has two, three, four footer layout feature.We focused on usability across various
devices, starting with smart phones.it is compatible with various devices. consultup is a
Cross-Browser Compatible theme that works on All leading web browsers. consultup is easy to use and 
user friendly theme. consultup has boxed and full-width layout feature.
Powerful but simple consultup theme content customized through customizer. to make your site attractive it has two 
widget sections first for “sidebar widget section” and second for “Footer widget section” . 

To make your website in two column use sidebar widget section. to set custom menu in header set primary location. we added social media links to added your social links.It boasts of beautifully designed page sections , Home, Blog and Default Page Template(page with right sidebar), Page Full-Width, Page Left Sidebar. consultup theme has more advanced feature to make your site awesome like: it has header top bar dark & lite color feature. you can also changed header color dark and lite styling. Theme compatible with woocommerce. consultup is a fully woocommerce tested theme. consultup is translation ready theme with WPML compatible & Many More….

This theme is compatible with Wordpress Version 4.4.2  and above and it supports the new theme customization API (https://codex.wordpress.org/Theme_Customization_API).

Supported browsers: Firefox, Opera, Chrome, Safari and IE10+ (Some css3 styles like shadows, rounder corners and 2D transform are not supported by IE8 and below).

/***** BUNDELED CSS ***/
============================================
This theme uses Underscores
============================================
 * consultup is based on Underscores. All the files in the theme package are from Underscores, unless stated otherwise.
 * Copyright: Automattic, automattic.com
 * Source: http://underscores.me/
 * License: GPLv2
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
* CSS bootstrap.css
Code and documentation copyright 2011-2016 Twitter, Inc. Code released under the MIT license. Docs released under Creative Commons.

* JS bootstrap.js
Copyright 2011-2018 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
https://github.com/twbs/bootstrap/blob/master/LICENSE

* Bootstrap navwalker
* Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>
https://github.com/twittem/wp-bootstrap-navwalker

== Font Awesome license ==
https://github.com/FortAwesome/Font-Awesome FontAwesome 4.7.0 Copyright 2012 Dave Gandy 
Font License: SIL OFL 1.1 Code License: MIT License http://fontawesome.io/license/`

== Smartmenu ==
======================================
 * Owner : https://github.com/vadikom
 * Copyright (c) Vasil Dinkov, Vadikom Web Ltd. ( https://github.com/vadikom/smartmenus/blob/master/LICENSE-MIT)
 * Licensed under https://github.com/vadikom/smartmenus
 

License for images:
/**** Images Source *****/
============================================
	Stocksnap Images
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://stocksnap.io/license
	
	Banner & Bredcrumb Image, Copyright Burst
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://stocksnap.io/photo/XJD4Q6CXDI

========================================================================================	
--- Version 0.9 ----
1. Relesed

--- Version 1.0 ----
1. Fixed styling issue.

--- Version 1.1 ----
1. Fixed string issue.

--- Version 1.2 ----
1. Fixed styling issue.

--- Version 1.3 ----
1. Fixed header icon issue.

--- Version 1.4 ----
1. Fixed Index page issue.

--- Version 1.5 ----
1. Fixed styling issue.

--- Version 1.5.1 ----
1. Fixed styling issue.

--- Version 1.5.2 ----
1. Added skip links.

--- Version 1.5.3 ----
1. Fixed escaping issue.

--- Version 1.5.4 ----
1. Fixed styling issue.