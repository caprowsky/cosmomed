<?php /**
 // Template Name: Homepage
 */
get_header();
do_action( 'icycp_consultup_homepage_sections', false );
get_footer();